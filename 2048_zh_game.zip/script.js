
const size = 4;
const game = document.getElementById("game");
const scoreDisplay = document.getElementById("score");
const highscoreDisplay = document.getElementById("highscore");
let board = [];
let score = 0;
let highscore = localStorage.getItem("highscore") || 0;
highscoreDisplay.textContent = `最高分：${highscore}`;

const chineseNumbers = {
  2: "二", 4: "四", 8: "八", 16: "十六", 32: "三十二",
  64: "六十四", 128: "一二八", 256: "二五六",
  512: "五一二", 1024: "一零二四", 2048: "二零四八"
};

function updateScore(add) {
  score += add;
  scoreDisplay.textContent = `分數：${score}`;
  if (score > highscore) {
    highscore = score;
    localStorage.setItem("highscore", highscore);
    highscoreDisplay.textContent = `最高分：${highscore}`;
  }
}

function createBoard() {
  game.innerHTML = "";
  board = [];
  score = 0;
  updateScore(0);
  for (let i = 0; i < size * size; i++) {
    const cell = document.createElement("div");
    cell.classList.add("cell");
    cell.textContent = "";
    cell.dataset.value = 0;
    game.appendChild(cell);
    board.push(cell);
  }
  generate(); generate();
}

function generate() {
  let emptyCells = board.filter(cell => cell.dataset.value == 0);
  if (emptyCells.length === 0) return;
  let cell = emptyCells[Math.floor(Math.random() * emptyCells.length)];
  let value = Math.random() < 0.9 ? 2 : 4;
  cell.dataset.value = value;
  cell.textContent = chineseNumbers[value];
  cell.classList.add("shake");
  setTimeout(() => cell.classList.remove("shake"), 300);
}

function isGameOver() {
  for (let i = 0; i < size * size; i++) {
    if (board[i].dataset.value == 0) return false;
    const r = Math.floor(i / size), c = i % size;
    const val = +board[i].dataset.value;
    if (r < size - 1 && +board[(r + 1) * size + c].dataset.value === val) return false;
    if (c < size - 1 && +board[r * size + c + 1].dataset.value === val) return false;
  }
  return true;
}

function move(dir) {
  let moved = false;
  const getIndex = (r, c) => r * size + c;
  for (let i = 0; i < size; i++) {
    let line = [];
    for (let j = 0; j < size; j++) {
      let idx = dir === "left" || dir === "right" ? getIndex(i, j) : getIndex(j, i);
      let cell = board[idx];
      if (cell.dataset.value != 0) line.push(+cell.dataset.value);
    }
    if (dir === "right" || dir === "down") line.reverse();
    for (let j = 0; j < line.length - 1; j++) {
      if (line[j] === line[j + 1]) {
        line[j] *= 2;
        updateScore(line[j]);
        line.splice(j + 1, 1);
      }
    }
    while (line.length < size) line.push(0);
    if (dir === "right" || dir === "down") line.reverse();
    for (let j = 0; j < size; j++) {
      let idx = dir === "left" || dir === "right" ? getIndex(i, j) : getIndex(j, i);
      if (board[idx].dataset.value != line[j]) moved = true;
      board[idx].dataset.value = line[j];
      board[idx].textContent = line[j] === 0 ? "" : chineseNumbers[line[j]] || line[j];
    }
  }
  if (moved) {
    generate();
    if (isGameOver()) {
      setTimeout(() => alert("☠️ 遊戲結束！"), 100);
    }
  }
}

document.addEventListener("keydown", e => {
  switch (e.key) {
    case "ArrowUp": move("up"); break;
    case "ArrowDown": move("down"); break;
    case "ArrowLeft": move("left"); break;
    case "ArrowRight": move("right"); break;
  }
});

createBoard();
